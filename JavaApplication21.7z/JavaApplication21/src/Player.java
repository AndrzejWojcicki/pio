
import java.util.Scanner;

public abstract class Player {

    public String name;
    public Scanner odczyt;

    public Player(String name) {
        setName(name);
    }

    public void setName(String name) {

        if (name != null || !name.isEmpty()) {
            name = odczyt.nextLine();
            this.name = name;
        } else {
            System.err.println("Błąd, źle wprowadzone imie");
        }

    }

    public void getName() {

        System.out.println("imie" + name);
    }
    abstract public int guess();

}
