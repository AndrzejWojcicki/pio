
import java.util.Scanner;

public abstract class Player {

    private String name = "Wariat";
    public Scanner odczyt;
    
    public Player(){}
    
    public Player(String name) {
        setName(name);
    }
//regex101 "^[a-zA-Z][a-zA-Z0-9\.,_@-]{1,}$"
    public void setName(String name) {
        
        if (name != null && !name.matches("^[a-zA-Z][a-zA-Z0-9\\.,_@-]{1,}$")) {
            name = odczyt.nextLine();
            this.name = name;
        } else {
            throw new IllegalArgumentException(); 
        }

    }
    public String toString(){
        //return this.getClass().getSimpleName()+ " ; " + name;
        //return name;
        return super.toString() + "  :  " + name;
    }

    public void getName() {

        System.out.println("imie" + name);
    }
    abstract public int guess();

}
