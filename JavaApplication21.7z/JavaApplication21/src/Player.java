
import java.util.Scanner;

public abstract class Player {

    private String name = "Wariat";
    private TextInput in;
    
    public Player(){}
    
    public Player(String name) {
        setName(name);
    }
//regex101 "^[a-zA-Z][a-zA-Z0-9\.,_@-]{1,}$"
    public void setName(String name) {
        
        if (name != null && name.matches("^[a-zA-Z][a-zA-Z0-9\\.,_@-]{1,}$")) {
            this.name = name;
        } else {
            throw new IllegalArgumentException(); 
        }

    }
    public void askForName(){
        
        //ConsoleInput in = new ConsoleInput(); 
        GUIInput in = new GUIInput();
        setName(in.getText());
    
        
    }
    public String toString(){
        //return this.getClass().getSimpleName()+ " ; " + name;
        //return name;
        return super.toString() + "  :  " + name;
    }

    public void getName() {

        System.out.println("imie" + name);
    }
    abstract public int guess();

    void setTextInput(TextInput in) {
        this.in=in;
         
        
    }

   

}
