import java.util.Random;

public class Main {

    public static void main(String[] args) {
        int x, y;
        Random rand = new Random();
        Player gracz = new PlayerComp(null);

        while (true) {
            System.out.println("podaj liczbe od 1 do 6 ");
            y = rand.nextInt(6) + 1;
            x = gracz.guess();

            if (x == y) {
                System.out.println("trafione ");
                break;
            } else {
                System.out.println("nie trafione " + y);
            }
        }

    }

}
