
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        int x, y;
        /*   
        Player gracz = new PlayerComp();
        Game game = new Game();
        gracz.setTextInput(new ConsoleInput());
        game.addPlayer(gracz);
        game.play(); */
        List<String> list = new ArrayList();
        //genercis do sprawdzenia
        list.add("raz");
        list.add("dwa");
        list.add("trzy");
        /*for(int i=0;i<list.size();i++){
        System.out.println(list.get(i));
    }*/
 /*
    for( String o : list  ){
        System.out.println(o);
    }*/
        Iterator<String> it = list.iterator();
       
        while (it.hasNext() == true) {
            System.out.println(it.next());
        }
        it.remove();

    }

}
