
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        int x, y;
        Random rand = new Random();
        Player gracz = new PlayerComp();
        try {
            gracz.setName("ga");
        } catch (Exception e) {
            System.err.println("Błąd " + gracz.toString());
        }

        while (true) {
            System.out.println("_______________________");
            System.out.println("podaj liczbe od 1 do 6 ");
            y = rand.nextInt(6) + 1;
            x = gracz.guess();
            System.out.println("Moja odpowiedz to: "+x);

            if (x == y) {
                System.out.println("Brawo Zgadles ");
                System.out.println("Na kostce także wypadlo: "+y);
                break;
            } else {
                System.out.println("Niestety nie");
                System.out.println("Na kostce wypadlo: "+y);
            }
            System.out.println("_______________________");
        }
        System.out.println("_______________________");

    }

}
