
import java.util.Random;

public class Game {

    protected Player gracz;
    protected Random rand = new Random();

    public void addPlayer(Player gracz) {
        
        this.gracz = gracz;
        gracz.setTextInput(new ConsoleInput());
         try {
            gracz.setName("Gracz");
            gracz.askForName();
        } catch (Exception e) {
            System.err.println("Błąd " + gracz.toString());
        }

    }

    public void play() {
        int x, y;
        System.out.println(gracz.getName());
        
        while (true) {
            System.out.println("_______________________");
            System.out.println("podaj liczbe od 1 do 6 ");
            y = rand.nextInt(6) + 1;
            x = gracz.guess();
            System.out.println("Moja odpowiedz to: " + x);

            if (x == y) {
                System.out.println("Brawo Zgadles ");
                System.out.println("Na kostce także wypadlo: " + y);
                break;
            } else {
                System.out.println("Niestety nie");
                System.out.println("Na kostce wypadlo: " + y);
            }
            System.out.println("_______________________");
        }
        System.out.println("_______________________");

    }
}
