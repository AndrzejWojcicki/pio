
public abstract interface TextInput {
    
  public String getText();
}
