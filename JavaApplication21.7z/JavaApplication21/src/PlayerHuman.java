
import java.util.Scanner;

public class PlayerHuman extends Player {

    private final Scanner cin = new Scanner(System.in);
    public PlayerHuman(){
        
    }
    public PlayerHuman(String name) {
        super(name);
    }


    @Override
    public int guess() {
        
           System.out.println("Ile oczek na kostce: ");
        return cin.nextInt();
    }
    

}
