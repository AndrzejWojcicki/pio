
import java.util.Scanner;


public class ConsoleInput implements TextInput {

    
    public String getText(){
        Scanner wpis = new Scanner(System.in);
        System.out.println("Podaj tekst: ");
        return wpis.nextLine();
    }
}
