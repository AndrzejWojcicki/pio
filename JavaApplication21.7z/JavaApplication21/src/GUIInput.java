
import javax.swing.JOptionPane;




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Student
 */
public class GUIInput implements TextInput {
   
    
    public String getText(){
     String tekst = JOptionPane.showInputDialog("Podaj imie");
    return tekst;
    }

    
}
