
import java.util.Random;

public class PlayerComp extends Player {

    private final Random rand = new Random();
    public PlayerComp(String name) {
        super(name);
    }

    PlayerComp(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    @Override
    public int guess() {
        return rand.nextInt(6) + 1;
    }
}
